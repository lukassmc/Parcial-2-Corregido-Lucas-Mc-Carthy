
package model;

import java.io.Serializable;
import java.util.Objects;
import services.CSVSerializable;


public class Animal implements Comparable<Animal>, CSVSerializable, Serializable {

    private static final long serialVersionUID = 1l;
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;
    
       public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animal other = (Animal) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.especie, other.especie)) {
            return false;
        }
        return this.alimentacion == other.alimentacion;
    }

    @Override
    public int compareTo(Animal o) {
       return Integer.compare(id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion.toString();
    }

    
     public static Animal fromCSV(String animalCSV){
       if (animalCSV.endsWith ("\n") ) {
            animalCSV = animalCSV.substring(0, animalCSV.length () - 1);
       }
       String[] valores = animalCSV.split(",");
       
       return new Animal(Integer.parseInt(valores[0]),
              valores[1], 
              valores[2],
              TipoAlimentacion.valueOf(valores[3]));
   }
       
       
    
}
